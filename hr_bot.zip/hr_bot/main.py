import os
from dotenv import load_dotenv
from llm_client import LLMClient  # ✅ заменили на новый универсальный клиент
from scoring import base_similarity_score, detect_gaps
from qa_logic import generate_followup_question, integrate_followup

load_dotenv()

# === Настройка модели ===
llm = LLMClient(
    provider="gemini",  # или "ollama", если хочешь локально
    model="gemini-1.5-flash",
    api_key=os.getenv("GOOGLE_API_KEY")
)

# === Пример данных ===
vacancy = {
    "город": "Астана",
    "опыт": 5,
    "должность": "junior python developer",
    "образование": "высшее специальное",
    "языки": ["английский"],
    "зарплата": 800000,
    "занятость": "частичная",
    "skills": ["python", "pandas", "numpy", "fastapi"]
}

resume = {
    "город": "Караганда",
    "опыт": 1,
    "должность": "junior python разработчик",
    "образование": "бакалавр компьютерных наук",
    "языки": ["русский"],
    "зарплата": 500000,
    "занятость": "полная",
    "skills": ["python", "fastapi", "docker"]
}


# === Основной сценарий ===
if __name__ == "__main__":
    # читаем базовую релевантность
    base = base_similarity_score(vacancy, resume)
    print(f"\nБазовая релевантность: {base['base_score']}%\n")

    #Ищем пробелы (несоответствия)
    gaps = detect_gaps(vacancy, resume, base)
    if not gaps:
        print("Несоответствий не найдено, кандидат полностью подходит.")
    else:
        print("Обнаружены моменты, требующие уточнения:\n")

    # Автоматические follow-up вопросы от модели
    followups = []
    for gap in gaps:
        question = generate_followup_question(gap, vacancy, resume, llm)
        print("BOT:", question)
        answer = input("Ваш ответ: ").strip()
        followups.append({"gap": gap, "answer": answer})

    # Финальная оценка
    if followups:
        final_score = integrate_followup(vacancy, resume, base, followups)
        print(f"\n Итоговая оценка после уточнений: {final_score}%")
        if final_score >= 75:
            print("Рекомендация: кандидат подходит.")
        elif final_score >= 50:
            print("Рекомендация: возможно подходит после обучения или уточнений.")
        else:
            print("Рекомендация: кандидат не подходит.")
