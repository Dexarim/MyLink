import json
import requests
from functools import lru_cache
from typing import Optional, List


# === Универсальный клиент LLM ===
class LLMClient:
    def __init__(
        self,
        provider: str = "gemini",  # gemini | mistral | ollama
        model: str = "gemini-1.5-flash",
        base_url: str = "http://localhost:11434",
        api_key: Optional[str] = None
    ):
        """
        provider:
            "gemini"  — для Google Gemini API
            "mistral" или "ollama" — для локальных моделей через Ollama API
        """
        self.provider = provider
        self.model = model
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key

    # === Основная функция генерации текста ===
    @lru_cache(maxsize=128)
    def generate(self, prompt: str) -> str:
        if self.provider == "gemini":
            return self._generate_gemini(prompt)
        elif self.provider in ("mistral", "ollama"):
            return self._generate_ollama(prompt)
        else:
            return "[Ошибка: неизвестный провайдер LLM]"

    # === Gemini API ===
    def _generate_gemini(self, prompt: str) -> str:
        try:
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model}:generateContent?key={self.api_key}"
            headers = {"Content-Type": "application/json"}
            data = {"contents": [{"parts": [{"text": prompt}]}]}
            resp = requests.post(url, headers=headers, json=data, timeout=30)
            resp.raise_for_status()
            data = resp.json()
            return data["candidates"][0]["content"]["parts"][0]["text"].strip()
        except Exception as e:
            return f"[Ошибка Gemini: {e}]"

    # === Ollama / Mistral ===
    def _generate_ollama(self, prompt: str) -> str:
        try:
            resp = requests.post(
                f"{self.base_url}/api/generate",
                json={"model": self.model, "prompt": prompt},
                stream=True,
                timeout=30
            )
            text = ""
            for line in resp.iter_lines():
                if not line:
                    continue
                data = json.loads(line.decode("utf-8"))
                text += data.get("response", "")
            return text.strip()
        except Exception as e:
            return f"[Ошибка Ollama: {e}]"


# === Клиент для эмбеддингов (опционально) ===
class EmbeddingClient:
    def __init__(
        self,
        model: str = "text-embedding-3-small",
        api_key: Optional[str] = None,
        base_url: str = "https://api.openai.com/v1/embeddings"
    ):
        self.model = model
        self.api_key = api_key
        self.base_url = base_url

    def embed(self, text: str) -> List[float]:
        """Создаёт векторное представление текста"""
        try:
            headers = {"Authorization": f"Bearer {self.api_key}"}
            data = {"model": self.model, "input": text}
            resp = requests.post(self.base_url, headers=headers, json=data, timeout=15)
            resp.raise_for_status()
            result = resp.json()
            return result["data"][0]["embedding"]
        except Exception as e:
            print(f"[Ошибка Embedding API: {e}]")
            return []
