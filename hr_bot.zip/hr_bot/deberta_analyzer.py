from transformers import AutoTokenizer, AutoModelForSequenceClassification, pipeline
from typing import List, Dict
import torch
import os


# === Ленивый singleton для DeBERTa pipeline ===
MODEL_NAME = os.getenv("DEBERTA_MODEL", "microsoft/deberta-v3-base")


class DebertaWrapper:
    """Лениво создаёт pipeline при первом использовании."""

    def __init__(self, model_name: str = MODEL_NAME):
        self.model_name = model_name
        self._nlp = None

    def _init(self):
        if self._nlp is not None:
            return
        print("[DeBERTa] Инициализация модели...")
        tokenizer = AutoTokenizer.from_pretrained(self.model_name)
        model = AutoModelForSequenceClassification.from_pretrained(self.model_name, num_labels=2)
        # Позволяем переопределить устройство через переменную окружения DEBERTA_DEVICE
        device_env = os.getenv("DEBERTA_DEVICE")
        if device_env is not None:
            try:
                device = int(device_env)
            except ValueError:
                device = 0 if torch.cuda.is_available() else -1
        else:
            device = 0 if torch.cuda.is_available() else -1

        self._nlp = pipeline(
            "text-classification",
            model=model,
            tokenizer=tokenizer,
            device=device
        )
        print("[DeBERTa] Модель готова ✅")

    @property
    def nlp(self):
        if self._nlp is None:
            self._init()
        return self._nlp


# глобальный экземпляр, но модель загрузится только при первом обращении
_DEBERTA = DebertaWrapper()


# === Функция анализа одного требования ===
def check_requirement_match(requirement: str, resume_text: str) -> Dict:
    """
    Сравнивает одно требование вакансии с текстом резюме и возвращает уровень совпадения.
    """
    prompt = f"Requirement: {requirement}\nResume: {resume_text}"
    result = _DEBERTA.nlp(prompt)[0]

    return {
        "requirement": requirement,
        "match": True if result["label"] == "LABEL_1" else False,
        "confidence": round(result["score"] * 100, 2)
    }


# === Анализ всех требований вакансии ===
def evaluate_resume_against_requirements(
    requirements: List[str],
    resume_text: str
) -> Dict:
    """
    Оценивает резюме по списку требований и возвращает детальный отчёт.
    """
    matches = [check_requirement_match(req, resume_text) for req in requirements]

    # Рассчитываем общий средний балл
    avg_confidence = round(sum(m["confidence"] for m in matches) / len(matches), 2)

    # Считаем, сколько требований кандидат "выполняет"
    passed = sum(1 for m in matches if m["match"])
    total = len(matches)

    return {
        "summary": {
            "total_requirements": total,
            "matched": passed,
            "average_confidence": avg_confidence,
            "score_percent": round((passed / total) * 100, 2)
        },
        "details": matches
    }


# === Пример использования ===
if __name__ == "__main__":
    # Пример данных (ты можешь заменить их на свои)
    job_requirements = [
        "Опыт работы с Python не менее 2 лет",
        "Знание библиотек pandas и numpy",
        "Умение работать с Linux"
    ]

    resume_text = """
    Программист с опытом 3 года в Python.
    Разрабатывал backend с использованием FastAPI, pandas и numpy.
    Работаю на Ubuntu Linux.
    """

    result = evaluate_resume_against_requirements(job_requirements, resume_text)

    print("\n=== РЕЗУЛЬТАТ АНАЛИЗА ===")
    print("Совпадения:", result["summary"])
    for r in result["details"]:
        print(f"- {r['requirement']} → {'✅' if r['match'] else '❌'} ({r['confidence']}%)")
