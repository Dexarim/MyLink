from typing import Dict, List, Any
from embeddings import cosine_sim, safe_float, embed_text


# === Расчёт базовой релевантности (с учётом навыков) ===
def base_similarity_score(vacancy: Dict, resume: Dict) -> Dict:
    # Веса переопределены: добавлен вес для skills
    weights = {
        "город": 0.05,
        "опыт": 0.20,
        "должность": 0.20,
        "образование": 0.12,
        "skills": 0.20,
        "языки": 0.08,
        "зарплата": 0.10,
        "занятость": 0.05
    }

    # === простые поля ===
    city_match = 0.0
    if vacancy.get("город") and resume.get("город"):
        city_match = 1.0 if vacancy["город"].lower() == resume["город"].lower() else 0.0

    exp_ratio = min(safe_float(resume.get("опыт")) / safe_float(vacancy.get("опыт"), 1.0), 1.0)
    salary_match = 1.0 if safe_float(resume.get("зарплата")) <= safe_float(vacancy.get("зарплата")) else 0.8

    # === семантические поля ===
    job_sim = cosine_sim(embed_text(vacancy.get("должность", "")), embed_text(resume.get("должность", "")))
    edu_sim = cosine_sim(embed_text(vacancy.get("образование", "")), embed_text(resume.get("образование", "")))

    # === навыки ===
    vac_skills = vacancy.get("skills") or vacancy.get("навыки") or []
    res_skills = resume.get("skills") or resume.get("навыки") or []
    if isinstance(vac_skills, str):
        vac_skills = [s.strip() for s in vac_skills.split(",") if s.strip()]
    if isinstance(res_skills, str):
        res_skills = [s.strip() for s in res_skills.split(",") if s.strip()]

    skills_overlap = 0.0
    if vac_skills:
        set_v = set([s.lower() for s in vac_skills])
        set_r = set([s.lower() for s in res_skills])
        skills_overlap = len(set_v & set_r) / len(set_v) if len(set_v) > 0 else 0.0

    skills_emb_sim = 0.0
    if vac_skills and res_skills:
        vac_text = ", ".join(vac_skills)
        res_text = ", ".join(res_skills)
        skills_emb_sim = cosine_sim(embed_text(vac_text), embed_text(res_text))

    skills_sim = round((0.6 * skills_overlap + 0.4 * skills_emb_sim), 4)

    # === языки ===
    langs_v = set(vacancy.get("языки", []))
    langs_r = set(resume.get("языки", []))
    langs_match = len(langs_v & langs_r) / len(langs_v) if langs_v else 1.0

    employment_match = 1.0 if vacancy.get("занятость") == resume.get("занятость") else 0.0

    score = (
        city_match * weights["город"] +
        exp_ratio * weights["опыт"] +
        job_sim * weights["должность"] +
        edu_sim * weights["образование"] +
        skills_sim * weights["skills"] +
        langs_match * weights["языки"] +
        salary_match * weights["зарплата"] +
        employment_match * weights["занятость"]
    ) * 100

    return {
        "base_score": round(score, 2),
        "details": {
            "city_match": city_match,
            "exp_ratio": exp_ratio,
            "job_sim": job_sim,
            "edu_sim": edu_sim,
            "skills_sim": skills_sim,
            "langs_match": langs_match,
            "salary_match": salary_match,
            "employment_match": employment_match
        }
    }



def detect_gaps(vacancy: Dict, resume: Dict, scoring: Dict) -> List[Dict]:
    """
    Анализирует расхождения между вакансией и резюме.
    Использует как численные метрики (из scoring), так и прямые проверки данных.
    """
    gaps = []
    d = scoring.get("details", {})

    # === 1. Город ===
    if vacancy.get("город") and resume.get("город"):
        if vacancy["город"].lower() != resume["город"].lower():
            gaps.append({
                "type": "relocation",
                "reason": f"вакансия в {vacancy['город']}, а кандидат проживает в {resume['город']}"
            })

    # === 2. Опыт работы ===
    # Учитываем как прямое значение, так и числовой показатель exp_ratio
    if d.get("exp_ratio", 1.0) < 0.7 or resume.get("опыт_лет", 0) < vacancy.get("требуемый_опыт", 0):
        gaps.append({
            "type": "training",
            "reason": "опыт кандидата меньше требуемого по вакансии"
        })

    # === 3. Образование ===
    if d.get("edu_sim", 1.0) < 0.6 or (
        vacancy.get("образование") and resume.get("образование") and
        vacancy["образование"].lower() not in resume["образование"].lower()
    ):
        gaps.append({
            "type": "education",
            "reason": "уровень или профиль образования отличается от требований"
        })

    # === 4. Зарплата ===
    if resume.get("зарплата") and vacancy.get("зарплата"):
        if resume["зарплата"] > vacancy["зарплата"]:
            gaps.append({
                "type": "salary",
                "reason": f"ожидания по зарплате ({resume['зарплата']}₸) выше предложенной ({vacancy['зарплата']}₸)"
            })

    # === 5. Языки ===
    if "языки" in vacancy and "языки" in resume:
        missing_langs = [lang for lang in vacancy["языки"] if lang not in resume["языки"]]
        if missing_langs:
            gaps.append({
                "type": "language",
                "reason": f"отсутствуют требуемые языки: {', '.join(missing_langs)}",
                "missing_langs": ", ".join(missing_langs)
            })

    # === 5.1 Навыки (skills) ===
    vac_skills = vacancy.get("skills") or vacancy.get("навыки") or []
    res_skills = resume.get("skills") or resume.get("навыки") or []
    if isinstance(vac_skills, str):
        vac_skills = [s.strip() for s in vac_skills.split(",") if s.strip()]
    if isinstance(res_skills, str):
        res_skills = [s.strip() for s in res_skills.split(",") if s.strip()]

    if vac_skills:
        set_v = set([s.lower() for s in vac_skills])
        set_r = set([s.lower() for s in res_skills])
        missing = list(set_v - set_r)
        if len(missing) / max(1, len(set_v)) > 0.4:
            gaps.append({
                "type": "skills",
                "reason": f"нехватка ключевых навыков: {', '.join(missing)}",
                "missing_skills": missing
            })

    # === 6. Тип занятости ===
    if vacancy.get("занятость") and resume.get("занятость"):
        if vacancy["занятость"].lower() != resume["занятость"].lower():
            gaps.append({
                "type": "employment",
                "reason": f"вакансия требует {vacancy['занятость']}, а кандидат предпочитает {resume['занятость']}"
            })

    # === 7. Мотивация ===
    if not resume.get("мотивация") or len(resume["мотивация"].strip()) < 30:
        gaps.append({
            "type": "motivation",
            "reason": "в резюме отсутствует информация о мотивации или профессиональных целях"
        })

    return gaps

